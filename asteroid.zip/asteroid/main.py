from if3_game.engine import Game, Layer, init
from game import Asteroid, RESOLUTION

init(RESOLUTION, "Astéroid")

s1 = Asteroid((300,200),(200, 0),20)


game_layer = Layer()
game_layer.add(s1)


game = Game()
game.add(game_layer)

game.run()
