from if3_game.engine import Sprite
RESOLUTION = [1024, 740]

class SpaceElement(Sprite):

    def __init__(self, image, position, image_anchor, initial_speed=[0, 0]):
        super().__init__(image, position, anchor=image_anchor)

        self.speed = initial_speed

    def update(self, dt):
        super().update(dt)

        x, y = self.position
        speed_x, speed_y =  self.speed
        
        x += speed_x * dt
        y += speed_y * dt
        
        rect = self.get_rect()

        if rect.left > RESOLUTION[0]:
            x = 0
        elif rect.right < 0:
            x = RESOLUTION[0]

        if rect.bottom > RESOLUTION[1]:
            y = 0
        elif rect.top < 0:
            y = RESOLUTION[1]

        self.position = x, y

class Asteroid(SpaceElement):

    def __init__(self, position, initial_speed, rotation_speed=0):
        super().__init__("sprites/asteroid128.png", position, (64,64), initial_speed)
        self.rotation_speed = rotation_speed

    def update(self, dt):
        super().update(dt)
        self.rotation += self.rotation_speed * dt