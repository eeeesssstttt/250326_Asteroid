from if3_game.engine import Game, Layer, init, Text, Sprite
from game import Asteroid, RESOLUTION, Ship, CENTER, UILayer
 
 
init(RESOLUTION, "Titre")
 
s1 = Asteroid((0,0), (50,65), rotation_speed = 30)
s2 = Asteroid((800,600), (-50,-65), rotation_speed = 30)
spaceship = Ship(CENTER)

background_layer = Layer()
background_layer.add(Sprite("sprites/background.jpg"))

game_layer = Layer()
game_layer.add(spaceship, s1, s2,)

ui_layer = UILayer(spaceship)

game = Game()
game.add(background_layer, game_layer, ui_layer)
#game.debug = True
 
game.run()