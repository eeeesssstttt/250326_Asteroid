from if3_game.engine import Game, Layer, init
from game import Asteroid, RESOLUTION, Ship, CENTER
 
 
init(RESOLUTION, "Titre")
 
s1 = Asteroid((0,0), (50,65), rotation_speed = 30)
s2 = Asteroid((800,600), (-50,-65), rotation_speed = 30)
ship = Ship(CENTER)
 
 
game_layer = Layer()
game_layer.add(s1, s2, ship)

game = Game()
game.add(game_layer)
game.debug = True
 
game.run()