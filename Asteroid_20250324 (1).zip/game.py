from if3_game.engine import Sprite
from pyglet.window import key
from math import radians, cos, sin
 
RESOLUTION=[800, 600]
CENTER = [RESOLUTION[0]/2, RESOLUTION[1]/2]
 
 
class SpaceElement(Sprite):
   
    def __init__(self, image, position, image_anchor, initial_speed = [0, 0]):
        super().__init__(image, position, anchor=image_anchor, collision_shape="circle")
 
        self.speed = initial_speed
 
    def update(self, dt):
        super().update(dt)
 
        x, y = self.position
        speed_x, speed_y = self.speed
 
        x += speed_x * dt
        y += speed_y * dt
 
        if y > 664:
            y = - 64
        elif y < -64:
            y = 664
        if x > 864:
             x = - 64
        elif x < - 64:
            x = 864
       
        self.position = x, y
     
 
class Asteroid(SpaceElement):
 
    def __init__(self, position, initial_speed, rotation_speed):
        super().__init__("sprites/asteroid128.png", position, (64,64), initial_speed)
        self.rotation_speed = rotation_speed
 
 
    def update(self,dt):
        super().update(dt)
        self.rotation += self.rotation_speed * dt

    def on_collision(self, other):
        super().on_collision(other)
        if isinstance(other, Ship):
            other.destroy()
 
class Ship(SpaceElement):
    def __init__(self, position):
        super().__init__("sprites/ship.png", position, (32, 64))
        self.rotation_speed = 0
        self.acceleration = 0
       
    def update(self,dt):
        speed_x, speed_y = self.speed

        angle = radians(-self.rotation + 90)
        acc_y = sin(angle) * self.acceleration
        acc_x = cos(angle) * self.acceleration

        speed_x += acc_x * dt
        speed_y += acc_y * dt
        
        self.speed = speed_x, speed_y
        super().update(dt)
        self.rotation += self.rotation_speed * dt
 
    def on_key_press(self, k, modifiers):
        if k == key.RIGHT:
            self.rotation_speed += 90
        if k == key.LEFT:
            self.rotation_speed -= 90
        if k == key.UP or k == key.SPACE:
            self.acceleration = 100
 
    def on_key_release(self, k, modifers):
        if k == key.RIGHT:
            self.rotation_speed -= 90
        if k == key.LEFT:
            self.rotation_speed += 90
        if k == key.UP or k == key.SPACE:
            self.acceleration = 0